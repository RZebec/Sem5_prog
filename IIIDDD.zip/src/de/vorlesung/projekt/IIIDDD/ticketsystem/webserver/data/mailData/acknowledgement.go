// 5894619, 6720876, 9793350
package mailData

/*
	A acknowledgement for a mail.
*/
type Acknowledgment struct {
	Id      string
	Subject string
}
