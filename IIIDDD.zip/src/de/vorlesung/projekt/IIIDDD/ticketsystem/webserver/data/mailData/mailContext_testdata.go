// 5894619, 6720876, 9793350
package mailData

const firstTestmailFileName = "2404E5B5-C952-3AE1-4CA3-B882B81DEAB4.json"
const firstTestMail = `{
    "Id": "2404E5B5-C952-3AE1-4CA3-B882B81DEAB4",
    "Sender": "notification@ticketsyste.de",
    "Receiver": "test2@test2.de",
    "Subject": "testSubject2",
    "Content": "TestContent2",
    "SentTime": 1546098015
}`

const secondTestmailFileName = "BFD0DBCD-5D01-4969-6201-E4F1172E568B.json"
const secondTestMail = `{
    "Id": "BFD0DBCD-5D01-4969-6201-E4F1172E568B",
    "Sender": "notification@ticketsyste.de",
    "Receiver": "test3@test2.de",
    "Subject": "testSubject3",
    "Content": "TestContent2",
    "SentTime": 1546098015
}`

const thirdTestmailFileName = "E395B1E5-79E7-3F1E-A92F-7B5C96F844F5.json"
const thirdTestMail = `{
    "Id": "E395B1E5-79E7-3F1E-A92F-7B5C96F844F5",
    "Sender": "notification@ticketsyste.de",
    "Receiver": "test1@test1.de",
    "Subject": "testSubject1",
    "Content": "TestContent1",
    "SentTime": 1546098015
}`
