// 5894619, 6720876, 9793350
package shared

const AuthenticationCookieName = "ApiAuthenticationKey"
const SendPath = "/api/mail/incoming"
const ReceivePath = "/api/mail/outgoing"
const AcknowledgmentPath = "/api/mail/acknowledge"
const AccessTokenCookieName = "AccessTokenCookie"
